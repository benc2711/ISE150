'''
Name
ISE150, Spring 2022
USC email
Homework 6
'''

import soundLibrary as sl

morseDict ={"A": ".-","B": "-...","C": "-.-.","D": "-..","E": ".","F": "..-.","G": "--.","H": "....","I": "..","J": ".---",
            "K": "-.-","L": ".-..","M": "--","N": "-.","O": "---","P": ".--.","Q": "--.-","R": ".-.","S": "...","T": "-","U": "..-",
            "V": "...-","W": ".--","X": "-..-","Y": "-.--","Z": "--..",}

morseOutput =""
userInput = input("Input a message to translate into morse code: ")
for x in range(len(userInput)):
        if userInput[x].upper() in morseDict:
            morseOutput += morseDict[userInput[x].upper()]
            morseOutput += " "
        else:
            morseOutput += " "
print(morseOutput)
userInputHear = input("Would you like to hear your morse code (y/n)? ")

if userInputHear.lower() == "y":
    sl.initSound()
    for x in range(len(morseOutput)):
        if morseOutput[x] == ".":
            sl.addMorseDot()
        if morseOutput[x] == "-":
            sl.addMorseDash()
        if morseOutput[x] ==" ":
            sl.addMorsePause()

    sl.playSound()
else:
    print("Goodbye!")


