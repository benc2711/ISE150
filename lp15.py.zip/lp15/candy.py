'''
Ben Crotty
ISE 150, Spring 2022
bcrotty@usc.edu
Lab 14
'''

class Candy(object):
    def __init__(self, inName, inCal):
        self = self
        # Assigning the member variables
        self.mName = inName
        self.mCal = inCal
